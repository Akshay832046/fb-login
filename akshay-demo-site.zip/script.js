document.getElementById("loginForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    document.getElementById("message").innerText =
        `Welcome, ${username}! (This is just a demo page.)`;
});
